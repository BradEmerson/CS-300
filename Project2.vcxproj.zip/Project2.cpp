#include <string>	//BME 10-10-23// Include statements include the necessary files/packages referenced by the code in this program
#include <iomanip>
#include <iostream>
#include <time.h>
#include <vector>
#include <fstream>
#include <cstring>
#include <sstream>
#include <map>
#include <istream>

//BME 10-10-23//	6. Industry Standard Best Practices : Apply industry standard best practices in code design.

using namespace std;			//BME 10-10-23// Uses standard namespace for all below this line

struct Course {					//BME 10-10-23// Creates Structure for each Course		
	string code;				//BME 10-10-23// Unique Identifier
	string title;
	string preReq;
	string preReq2;

	Course() {					//BME 10-10-23// Default Constructor for Course
		code = "A1";
		preReq = "No Prerequisites";
	}
};

struct Node {					//BME 10-10-23// Creates Structure for each Node
	Course course;
	Node* left;
	Node* right;

	Node() {					//BME 10-10-23// Default Constructor for Node
		left = nullptr;
		right = nullptr;
	}

	Node(Course aCourse) :		//BME 10-10-23// Initializes Node with a Course
		Node() {
		course = aCourse;
	}
};

class BinarySearchTree {		//BME 10-10-23// Defines class for BST
private:						//BME 10-10-23// Defines private variables/structures/functions
	Node* root;					//BME 10-10-23// Creates root node

	void addNode(Node* node, Course course);		//BME 10-10-23//	See function definitions below
	void inOrder(Node* node);						//BME 10-10-23//
	void preOrder(Node* node);                      //BME 10-10-23//
	void postOrder(Node* node);                     //BME 10-10-23//

public:							//BME 10-10-23// Defines public variables/structures/functions
	
	BinarySearchTree();								//BME 10-10-23//	See function definitions below
	virtual ~BinarySearchTree();					//BME 10-10-23//
	void InOrder();									//BME 10-10-23//
	void PreOrder();                                //BME 10-10-23//
	void PostOrder();                               //BME 10-10-23//
	void Insert(Course course);						//BME 10-10-23//
	Course Search(string code);						//BME 10-10-23//
};

BinarySearchTree::BinarySearchTree() {
	root = nullptr;									//BME 10-10-23//	Sets root to null
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {				//BME 10-10-23//    Not used in this instance, left intact for future expansion
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {					//BME 10-10-23//	Calls private InOrder traversal function 
	inOrder(root);									//BME 10-10-23//
}													//BME 10-10-23//

void BinarySearchTree::PostOrder() {				//BME 10-10-23//	Calls private PostOrder traversal function 
	postOrder(root);								//BME 10-10-23//
}													//BME 10-10-23//

void BinarySearchTree::PreOrder() {					//BME 10-10-23//	Calls private PreOrder traversal function
	preOrder(root);									//BME 10-10-23//
}													//BME 10-10-23//

vector<string> courses;								//BME 10-10-23//	Creates vector to store courses
vector<string> courseCounter;						//BME 10-10-23//	
map<int, int> parserMap;							//BME 10-10-23//

void BinarySearchTree::Insert(Course course) {					//BME 10-10-23//	Inserts nodes into the BST
	if (root == nullptr) {										//
		root = new Node;										//  If root is null, creates root Node, sets root course to course passed to function.
		root->course = course;                                  //
		//cout << "Added Root " << root->course.code << endl;	//	This line used for testing, commented out to keep intact.
	}															//
	else {														//  Otherwise, adds a node with values of root pointer and course.
		addNode(root, course);									//
	}															//
}																//BME 10-10-23//
		
//BME 10-10-23//	5. Course Information : Develop working code to print course information.

Course BinarySearchTree::Search(string code) {					//BME 10-10-23//	Searches for the course code entered by the user and returns a match if it finds one.
	Node* currNode = new Node;									//
	currNode = root;											//
	while (currNode != nullptr) {								//  As long as the current node is not null, this will traverse the tree downward from the root.
		if (currNode->course.code == code) {					//
			return currNode->course;							//  If the node is found, this returns the course from the node.
		}														//
		else if (currNode->course.code > code) {				//  If the node's code is greater than the search code (code is less than node's), traverse left.
			currNode = currNode->left;							//
		}														//
		else {													//  Otherwise, traverse right.
			currNode = currNode->right;							//
		}														//
	}															//
	Course course;												//  Otherwise, return empty course.
	return course;												//
}																//BME 10-10-23//

void BinarySearchTree::addNode(Node* node, Course course) {		//BME 10-10-23//	Adds new nodes to the existing BST if root already exists.
	if (node->course.code > course.code) {                      //
		if (node->left == nullptr) {							//  If the passed course code is higher than the recursive node's course code:
			node->left = new Node;								//  If the next left node is null, insert node there with a pointer to this course code.
			node->left->course = course;                        //  Otherwise, traverse (recursive) left.
			//cout << course.code << " added left!" << endl;	//	This line used for testing, commented out to keep intact.
		}														//
		else {													//
			//cout << "Traversing Left..." << endl;				//	This line used for testing, commented out to keep intact.
			addNode(node->left, course);						//
		}														//
	}															//
	else {														//  Else:
		if (node->right == nullptr) {							//  If the next right node is null, insert node there with a pointer to this course.
			node->right = new Node;								//  Otherwise, traverse (recursive) right.
			node->right->course = course;                       //
			//cout << course.code << " added right!" << endl;   //	This line used for testing, commented out to keep intact.
		}														//
		else {													//
			//cout << "Traversing Right..." << endl;			//	This line used for testing, commented out to keep intact.
			addNode(node->right, course);						//
		}														//
	}															//
}																//BME 10-10-23//

// BME 10-10-2023 //	4. Course List : Develop working code to sort and print out a list of the courses in the Computer Science program in alphanumeric order

void BinarySearchTree::inOrder(Node* node) {					//BME 10-10-23// Traverses tree using InOrder algorithm
	if (node == nullptr) return;								//
		inOrder(node->left);									//
		cout << node->course.code << ": "						//  If node is not null:
		<< node->course.title									//  Traverse Left (recursive)
		<< endl;												//  Print Info
		cout << "Prerequisites: ";								//  Traverse Right (recursive)
		if (!node->course.preReq.empty()) {						//	If prerequisite exists, print it.
			cout << node->course.preReq;						//
		}														//
		if (!node->course.preReq2.empty()) {					//	If prerequisite 2 exists, print it.
			cout << ", ";										//
			cout << node->course.preReq2 << endl;				//
		}														//
		else cout << endl;										//	Otherwise, end printing.
		cout << endl;											//
		inOrder(node->right);									//BME 10-10-23//
}

void BinarySearchTree::postOrder(Node* node) {					//BME 10-10-23//  Traverses tree using PostOrder algorithm
	if (node != nullptr) {										//
		postOrder(node->left);									//
		postOrder(node->right);									//
		cout << node->course.code << ": "						//  If node is not null:
			<< node->course.title								//  Traverse Left (recursive)
			<< endl;											//  Traverse Right (recursive)
		cout << "Prerequisites: ";								//  Print Info
		if (!node->course.preReq.empty()) {						//	If prerequisite exists, print it.
			cout << node->course.preReq;						//
		}														//
		if (!node->course.preReq2.empty()) {					//	If prerequisite 2 exists, print it.
			cout << ", ";										//
			cout << node->course.preReq2 << endl;				//
		}														//
		else cout << endl;										//	Otherwise, end printing.
	}															//BME 10-10-23//
}

void BinarySearchTree::preOrder(Node* node) {					//BME 10-10-23//  Traverses tree using PreOrder algorithm
	if (node != nullptr) {										//
		cout << node->course.code << ": "						//  If node is not null:
			<< node->course.title								//  Print Info
			<< endl;											//  Traverse Left (recursive)
		cout << "Prerequisites: ";								//  Traverse Right (recursive)
		if (!node->course.preReq.empty()) {						//	If prerequisite exists, print it.
			cout << node->course.preReq;						//
		}														//
		if (!node->course.preReq2.empty()) {					//	If prerequisite 2 exists, print it.
			cout << ", ";										//
			cout << node->course.preReq2 << endl;				//
		}														//
		else cout << endl;										//	Otherwise, end printing.
		preOrder(node->left);									//
		preOrder(node->right);									//
	}															//
}																//BME 10-10-23//

void displayCourse(Course course) {								//BME 10-10-23// Print course and prequisites		
	cout << course.code << ": "									//
		<< course.title											//  
		<< endl;												//  
	cout << "Prerequisites: ";									//  
	if (!course.preReq.empty()) {								//	If prerequisite exists, print it.
		cout << course.preReq;									//
	}															//
	if (!course.preReq2.empty()) {								//	If prerequisite 2 exists, print it.
		cout << ", ";											//
		cout << course.preReq2 << endl;							//
	}															//
	else cout << endl;											//	Otherwise, end printing.
	return;														//
}																//BME 10-10-23//

// BME 10-10-2023 // 1. Input: Design code to correctly read the course data file.
// BME 10-10-2023 // 3. Loading Data Structure : Develop working code to load data from the file into the data structure.
static void fileParser(BinarySearchTree* bst) {					//BME 10-10-23//
																//
	if (courses.size() != 0) {									// This detects if the course vector has already been populated.  If it has, it clears it in order to avoid duplication.
		courses.clear();										//
	}															//
																//
	string filename = "ABCU Advising Program Input.txt";		//	Filename for .csv input
																//
	ifstream file;												//	Instantiates input file stream
																// 
	file.open(filename);										//	Opens the file
																//
	if (file.fail()) {											//	Provides failure feedback to user if unable to open file
		cout << "File did not open, something went wrong."		//
			<< endl;											//
	}															//
	else {														//
		cout << "File opened successfully." << endl;			//	Provides failure feedback to user if file opens correctly
	}															//
																//
	string line;												//	Instantiates line variable for storing comma separated values
	unsigned int i = 1;											//	
	unsigned int lineCounter = 0;								//
																//
	while (getline(file, line)) {								//	While the line is not empty:
																//
		string code;											//	Instantiates local variables and object for comma separated value detection and structure population
		string title;											//
		string preReq;											//
		string preReq2;											//
		Course course;											//
																//
		stringstream inputFile(line);							//	Instantiates new string stream using line variable
																//
		getline(inputFile, code, ',');							//	Takes comma separated values, stores them in their respective variables
		getline(inputFile, title, ',');							//
		getline(inputFile, preReq, ',');						//
		getline(inputFile, preReq2, ',');						//
																//
		if (code.length() > 0) {								//	If the variable isn't empty, populate the courseCounter vector, and insert variable's value into structure
			courseCounter.push_back(code);						//	(This applies to all four of these near-identical "if" statements
			course.code = code;									//
		}														//
		if (title.length() > 0) {								//
			courseCounter.push_back(title);						//
			course.title = title;								//
		}														//
		if (preReq.length() != 0) {								//
			courseCounter.push_back(preReq);					//
			course.preReq = preReq;								//
		}														//
		if (preReq2.length() != 0) {							//
			courseCounter.push_back(preReq2);					//
			course.preReq2 = preReq2;							//
		}														//
																//
		parserMap.insert(pair<int, int>(i, courseCounter.size()));//	Inserts i as the key, and courseCounter size into a map.  This is how I filtered/detected the number of CSVs on each line in the file
		++i;													//	Increments i, so that the key for the map is increased each iteration
		++lineCounter;											//	Increments lineCounter to detect numer of lines in the file as the function loops
		courseCounter.clear();									//	Clears the courseCounter vector
		if (!code.empty() && !title.empty()) {					//	Filters out lines that have less than two comma separated values, and excludes them from being inserted into the BST
			bst->Insert(course);								//	Inserts a new node with course into the BST
		}														//
	}															//
																//
	file.clear();												//	Clears the input filestream
	file.seekg(0, std::ios::beg);								//	Resets input filestream position to the beginning of the file
																//
	i = 0;														//  Resets i's value to 0
	//cout << lineCounter << " lines - Test 1 " << endl;		//  This line used for testing, commented out to keep intact.
	while (i < lineCounter) {									//	This function iterates over each key value in map, and only takes 
		//cout << "Map "										//	This line used for testing, commented out to keep intact.
		//  << i + 1											//	This line used for testing, commented out to keep intact.
		// << " is "											//	This line used for testing, commented out to keep intact.
		// << parserMap.at(i + 1) << endl;						//	This line used for testing, commented out to keep intact.
		if (parserMap.at(i + 1) >= 2) {							//	This function iterates over each key value in map, and only adds the values to the vector if there are more than 2 values on that line in the original .csv file.
			getline(file, line);								//	This is used to make sure that each course has a Course Code and Title, at minimum.
			courses.push_back(line);							//
		}														//
		else {													//  This skips over the line if there are less than 2 values on it.
			getline(file, line);								//
		}														//
		++i;													//	Inc i
	}															//
	file.close();												//	Closes the file
}																//BME 10-10-23//

void coursePrint() {
	for (unsigned i = 0; i < courses.size(); ++i) {		//BME 10-10-23// Prints list of all courses as they appear in the text file, without being sorted.
		cout << courses.at(i) << endl;					//
	}													//
}														//BME 10-10-23//

//	2. Menu: Design code to create a menu that prompts a user for menu options.
//	BME 10-10-23// (Just as a note, I stopped using the note slash marks down the side here as they became redundant.  The original purpose was to show what I had edited, but I made this entire program, so it would be on everything).
//	As you can see, I've realized this quite late, so I will leave what already exists, as it helps organization in my opinion.

int main(int argc) {																		//BME 10-10-23//	Main function.  
																							//	
	BinarySearchTree* bst;																	//	Instantiates new BST pointer
	bst = new BinarySearchTree;																//	Instantiates new BST
	int userSelection = 0;																	//	Creates variable for menu selection
	string searchText;																		//	Creates variable for users to search for course codes
	Course course;																			//	Instantiates new course vector
																							
	while (userSelection != 9) {															// Exits the menu if "9" is entered by the user

		cout << "Menu:" << endl;															// Menu selection options
		cout << "1 - Load Data Structure" << endl;
		cout << "2 - Print course list exactly as listed in text file" << endl;
		cout << "3 - Print alphanumerically sorted course list" << endl;
		cout << "4 - Print single course information (must have course code)" << endl;
		cout << "9 - Exit" << endl;

		cin >> userSelection;																// Gets user input for menu options
		cout << endl;

		if (userSelection == 1) {															// Reads the file and loads the data structures (A vector, a map, and a BST)
			fileParser(bst);
			cout << endl;
			cout << "Populated course structures successfully!" << endl << endl;
		}
		if (userSelection == 2) {															// Prints the vector, without sorting.
			coursePrint();
			cout << endl;
		}
		if (userSelection == 3) {															// Prints the BST, sorted alphanumerically.
			bst->InOrder();
			cout << endl;
		}
		if (userSelection == 4) {															//	Allows the user to search for a specific course code.
			cout << "Enter the course code you wish to search for:" << endl;
			cin >> searchText;
			cout << endl;

			course = bst->Search(searchText);
			if (course.code == "A1") {													// Catches default constructor course returned
				cout << "No course matching that course code was found." << endl;
			}
			else if (!course.code.empty()) {											// Prints actual course info
				displayCourse(course);
			}
			else {																		// Catches empty course
				cout << "No course matching that course code was found." << endl;
			}
			cout << endl;																//	Enters a space for formatting purposes
		}
		if (userSelection != 1 && userSelection != 2 && userSelection != 3 && userSelection != 4 && userSelection != 9) {	// Manual exception handling
			cout << "Please enter a valid menu option, " << userSelection << " is not a valid option." << endl;
			cin.clear();
			cin.ignore();
		}
	}
	cout << "You have selected option " << userSelection << " , Goodbye!" << endl;	// Exit message
	return 0;
}